import datetime
import functools
import operator
import re
import threading

import dateutil
from dateutil.relativedelta import relativedelta
from fuzzywuzzy import fuzz

# - Addresses


def replace_newline(func):
    def wrapper(*args, **kwargs):
        # first convert any None type args or kwargs to empty strings
        args = ["" if isinstance(arg, type(None)) else arg for arg in args]
        kwargs = {
            key: "" if isinstance(value, type(None)) else value
            for key, value in kwargs.items()
        }

        args = [arg.replace("\n", " ") if isinstance(arg, str) else arg for arg in args]
        kwargs = {
            key: value.replace("\n", " ") if isinstance(value, str) else value
            for key, value in kwargs.items()
        }
        return func(*args, **kwargs)

    return wrapper


def is_blank(value):
    """
    Determine if the value is blank or not
    """
    if value is None:
        return True
    if str(value).lower() in ["", "no transcription"]:
        return True
    return False


@functools.lru_cache(maxsize=500)
def address_normaliser(address):
    address = address.lower().replace(" au", "")
    postcode_pattern = r"(?<!\d)\b\d{4}\b"
    address = re.sub(postcode_pattern, "", address)
    states = [" qld ", " nsw ", " act ", " vic ", " tas ", " sa ", " wa ", " nt "]
    for state in states:
        address = address.replace(state, "")
    return address


@functools.lru_cache(maxsize=500)
@replace_newline
def address_match(address1, address2, threshold=76):
    """
    Compares two addresses and returns True if their similarity score is above a given
    threshold.

    :param address1: The first address to compare
    :param address2: The second address to be compared with the first address (address1)
    :param threshold: The minimum percentage match required for the two addresses to be considered a
    match. The default value is 80, which means that the two addresses must have at least an 80% match
    to be considered a match, defaults to 80 (optional)
    :return: a boolean value (True or False) based on whether the token sort ratio between the two input
    addresses is greater than or equal to the threshold value.
    """
    address1 = address_normaliser(address1)
    address2 = address_normaliser(address2)
    value = fuzz.token_sort_ratio(address1, address2)
    return True if value >= threshold else False


# - TFN
@functools.lru_cache(maxsize=10)
def _extract_tfn(string):
    """
    This Python function extracts a tax file number from a string if it contains the keywords
    "tfn" or "tax file number" and matches a specific pattern.

    :param string: a string that may contain a tfn or the phrase "tax file number"
    :return: either the tfn if it is found in the input string, or None if it is not
    found.
    """
    if "tfn" in string or "tax file number" in string.lower():
        pattern = r"\d{3}\s?\d{3}\s?\d{3}"
        match = re.search(pattern, string)
        if match:
            tfn = match.group(0)
            return tfn
        else:
            return None
    else:
        return None


@functools.lru_cache(maxsize=128)
def _is_valid_tfn(tfn):
    """
    Checks if a given input is a valid tfn using a specific algorithm.

    :param tfn: The parameter "tfn" is a variable that represents a Tax File Number.
    :return: a boolean value indicating whether the given input tfn is valid or not.
    True is returned if the tfn is valid, and False is returned if it is not valid.
    """
    tfn = str(tfn).replace(" ", "")
    if not tfn.isdigit() or len(tfn) != 9:
        return False
    weighting = [1, 4, 3, 7, 5, 8, 6, 9, 10]
    check_sum = sum(int(tfn[i]) * weighting[i] for i in range(9))
    return check_sum % 11 == 0


def tfn_full_shift_check(string):
    """
    The function checks for valid tfn's in a given string and returns a list of valid tfn's.

    :param string: The input string that contains one or more potential tfn's to be
    checked
    :return: a list of valid tfn's found in the input string. If no valid
    tfn's are found, an empty list is returned.
    """
    pattern = r"\d+"
    digits = re.findall(pattern, string)
    stream = "".join(digits)
    if len(stream) < 9:
        return False
    groups = []
    for i in range(len(stream) - 8):
        group = stream[i : i + 9]
        if not group.startswith("0"):
            groups.append(group)

    found_tfns = []
    for item in groups:
        if _is_valid_tfn(item):
            found_tfns.append(item)
    return found_tfns


def document_contains_tfn(string, full_check=True, **kwargs):
    """
    Checks if a given document contains a valid tfn and performs a full
    check if specified.

    :param string: a string that may or may not contain a tfn
    :param full_check: A boolean parameter that determines whether to perform a full check for the
    presence of a tfn in the given string. If set to True, the function will perform
    an additional check using the tfn_full_shift_check() function. If set to False, this check will be
    skipped, defaults to False (optional)
    :return: a boolean value (True or False) indicating whether the input string contains a valid tfn or not.
    If the optional parameter `full_check` is set to True, the function also
    performs a full shift check on the input string and returns True if the check passes.
    """
    tfn_value = _extract_tfn(string)
    if tfn_value is not None:
        if _is_valid_tfn(tfn_value):
            return True
    if full_check:
        max_gap = kwargs.get("max_gap", 6)
        ignore_comma = kwargs.get("ignore_comma", False)

        matches = tfn_full_page_extraction(
            string, max_gap=max_gap, ignore_comma=ignore_comma
        )
        for match in matches:
            if tfn_full_shift_check(match):
                return True
    return False


def tfn_full_page_extraction(string, max_gap=6, ignore_comma=False):
    """
    Finds all potential TFNs that exist in a document, where there are max_gap space or hyphen chars
    between digits (default is up to 6), and optionally ignore commas (default is False). A potential
    TFN has at least 8 numbers.

    :param string: a string that may or may not contain one or more TFNs
    :param max_gap: an integer parameter >= 0  that determines how many space or hyphen chars can exist between
    digits in order to be considered part of neighboring digits that form a TFN. If set to 0, then a TFN
    is only detected if there are no space or hyphen chars between digits, i.e. they are consecutive numbers.
    Defaults to 6 (optional).
    :param ignore_comma: a boolean that determines if comma characters should be ignored when detecting
    adjacent digits that may form a TFN. If True, then any number of commas can exists between digits and
    the digits will still be considered adjacent. If set to False, then if one or more commas exist between
    digits, the neighbouring digits on either side of the comma are kept as separate groups of numbers.
    Defaults to False (optional)
    :return: a list of strings, with each element containing a potential TFN. If no potential TFNs are found
    it returns an empty list
    """
    if int(max_gap) < 0:
        max_gap = 6

    if ignore_comma:
        string = string.replace(",", "")

    pattern = rf"(?:(?:\ |\-){{0,{max_gap}}}(?:\d)){{8,}}"
    matches = re.findall(pattern, string)  # Search for potential TFNs
    cleansed_matches = []
    for match in matches:
        cleansed_matches.append(match.replace("-", "").replace(" ", ""))

    return cleansed_matches


@replace_newline
def extract_abn(string, string_search=True):
    """
    This function extracts an ABN from a given string if it exists and is requested.

    :param string: The input string in which the ABN needs to be extracted
    :param string_search: A boolean parameter that determines whether to search for the keywords "abn"
    or "australian business number" in the input string before attempting to extract the ABN. If True,
    the function will only return an ABN if one of these keywords is found in the input string. If
    False, defaults to True (optional)
    :return: either the ABN found in the input string or None if no ABN is
    found. The function can also be configured to only return the ABN if the input string contains the
    words "abn" or "australian business number".
    """
    pattern = r"\d{2}\s?\d{3}\s?\d{3}\s?\d{3}"
    match = re.search(pattern, string)  # Search for abn
    if string_search:
        if "abn" in string or "australian business number" in string.lower():
            if match:
                return match.group(0)
            return None
        else:
            return None
    else:
        if match:
            return match.group(0)
        return None


@functools.lru_cache(maxsize=50)
@replace_newline
def _is_valid_abn(abn):
    """
    The function checks if a given ABN is valid or not.

    :param abn: is the ABN that needs to be validated
    :return: a boolean value (True or False) indicating whether the input ABN is valid or not.
    """
    abn = str(abn).replace(" ", "").replace("-", "")
    if not abn.isdigit() or len(abn) != 11:
        return False

    weighting = [10, 1, 3, 5, 7, 9, 11, 13, 15, 17, 19]
    modulus = 89

    temp_abn = [int(c) for c in abn if c.isdigit()]
    temp_abn[0] -= 1

    check_sum = sum(map(operator.mul, temp_abn, weighting)) % modulus
    if check_sum != 0:
        return False
    return True


def document_contains_abn(string):
    """
    if the string contains a valid ABN returns true else false
    """
    abn_value = extract_abn(string)
    if abn_value is not None:
        if _is_valid_abn(abn_value):
            return True
    return False


@replace_newline
def str_to_date(date_):
    """
    Converts a string date into a datetime object by trying different date formats and
    returning a default date if none of the formats work.

    :param date_: a string representing a date in various formats, such as '2022-01-01', 'Jan. 1, 2022',
    '1/1/22', etc
    :return: a datetime object representing the input date string in one of the specified formats, or a
    datetime object representing the date '31/12/2999' if none of the formats match the input string.

    >>> str_to_date('11 NOVEMBER 2023')
    datetime.datetime(2023, 11, 11, 0, 0)

    >>> str_to_date('11 November, 2023')
    datetime.datetime(2023, 11, 11, 0, 0)

    >>> str_to_date('11th NOVEMBER 2023')
    datetime.datetime(2023, 11, 11, 0, 0)

    >>> str_to_date('11NOVEMBER2023')
    datetime.datetime(2023, 11, 11, 0, 0)

    >>> str_to_date('2023-11-11')
    datetime.datetime(2023, 11, 11, 0, 0)

    >>> str_to_date('11.11.2023')
    datetime.datetime(2023, 11, 11, 0, 0)

    >>> str_to_date('11/Nov/2023')
    datetime.datetime(2023, 11, 11, 0, 0)

    >>> str_to_date('2023.Nov.11')
    datetime.datetime(2023, 11, 11, 0, 0)

    """
    try:
        symbols = ["-", ".", "_", " "]
        date_ = date_.lower()

        for s in symbols:
            date_ = date_.replace(s, "/")

        for appendix in ["nd", "th", ","]:
            date_ = date_.replace(appendix, "")

        # replace all occurences of 'st' in date
        # but not in the special case of 'august'
        date_ = re.sub(r"(?<!augu)st", "", date_)

        formats = [
            "%Y/%m/%d",
            "%Y/%b/%-d",
            "%Y/%b/%d",
            "%d/%m/%Y",
            "%-d/%m/%Y",
            "%d/%b/%Y",
            "%d%B%Y",
            "%d/%B/%Y",
            "%d/%m/%y",
            "%-d/%m/%y",
            "%d/%b/%y",
            "%d%B%y",
            "%d/%B/%y",
        ]

        for date_format in formats:
            try:
                dt = datetime.datetime.strptime(date_, date_format)
                return dt
            except ValueError:
                pass
    except:
        pass

    return datetime.datetime.strptime("31/12/2999", "%d/%m/%Y")


@replace_newline
def retokenise_date_period(string):
    """
    Args:
          string::str
            The date period range as string

    Returns:
          date0::str
            Start date of the date period as string
          date1::str
            End date of the date period as string
    """
    string = string.lower().replace("to", "")
    tokens = re.split(r"\W+", string)
    tokens = [token for token in tokens if token]

    date0 = "/".join(tokens[:3])
    date1 = "/".join(tokens[3:])
    return date0, date1


@replace_newline
def date_increment(date_, days=0, months=0, years=0):
    """
    Takes a date and increments it by a specified number of days, months, and/or years.

    :param date_: The date to be incremented. It can be either a string in the format 'YYYY-MM-DD' or a
    datetime object
    :param days: The number of days to add or subtract from the given date. If the value is negative, it
    will subtract the specified number of days from the given date, defaults to 0 (optional)
    :param months: The number of months to increment the date by. If months=2 and the input date is
    January 1st, the output date will be March 1st. If months=-2 and the input date is January 1st, the
    output date will be November 1st of the previous, defaults to 0 (optional)
    :param years: The number of years to increment the date by. If the value is positive, the date will
    be incremented into the future. If the value is negative, the date will be decremented into the
    past, defaults to 0 (optional)
    :return: a date object that is incremented by the number of days, months, and years specified in the
    function arguments. If the input date is a string, it is first converted to a date object using the
    `str_to_date` function.
    """
    if isinstance(date_, str):
        date_ = str_to_date(date_)
    return_date = date_ + relativedelta(days=days, months=months, years=years)
    return return_date


@replace_newline
def date_compare_range(start_date, end_date, input_date):
    """
    Checks if a given date falls within a specified range of dates.

    :param start_date: The starting date of the range to compare against
    :param end_date: I'm sorry, but the parameter "end_date" is not defined in the code snippet you
    provided. Please provide more information or context so I can assist you better
    :param input_date: The date that needs to be compared to the range of dates
    :return: a boolean value (True or False) depending on whether the input_date falls within the range
    of start_date and end_date.
    """
    if isinstance(start_date, str):
        start_date = str_to_date(start_date)
    if isinstance(end_date, str):
        end_date = str_to_date(end_date)
    if isinstance(input_date, str):
        input_date = str_to_date(input_date)

    if start_date <= input_date <= end_date:
        return True
    else:
        return False


@replace_newline
def date_range_split(date_):
    """
    Takes a string representing a date range and returns two date objects.

    :param date_: a string representing a date range in the format 'start date to end date' or 'start
    date - end date' where the dates are in the format 'month day year' or 'month year' or 'year'
    :return: The function `date_range_split` returns a tuple containing two date objects, `date_0` and
    `date_1`.

    >>> date_range_split('11 NOVEMBER 2023 TO 22 MARCH 2024')
    (datetime.datetime(2023, 11, 11, 0, 0), datetime.datetime(2024, 3, 22, 0, 0))

    >>> date_range_split('11 NOVEMBER 2023 TO 22 MARCH 2024')
    (datetime.datetime(2023, 11, 11, 0, 0), datetime.datetime(2024, 3, 22, 0, 0))

    >>> date_range_split('11.11.2023 - 22.3.2024')
    (datetime.datetime(2023, 11, 11, 0, 0), datetime.datetime(2024, 3, 22, 0, 0))

    >>> date_range_split('11TH NOVEMBER 2023 TO 22ND MARCH, 2024')
    (datetime.datetime(2023, 11, 11, 0, 0), datetime.datetime(2024, 3, 22, 0, 0))

    >>> date_range_split('11.11.2023 22.03.2024')
    (datetime.datetime(2023, 11, 11, 0, 0), datetime.datetime(2024, 3, 22, 0, 0))

    """
    date_0, date_1 = retokenise_date_period(date_)

    dt_0 = str_to_date(date_0)
    try:
        dt_1 = str_to_date(date_1)
    except:
        dt_1 = datetime.datetime(2999, 12, 30, 0, 0)
    return dt_0, dt_1


@replace_newline
def get_tax_year(date_):
    """
    Returns the tax year based on the input date.

    :param date_: The input parameter "date_" is a date object or a string representing a date
    :return: the tax year based on the input date. If the month of the input date is greater than or
    equal to 7, the function returns the year of the input date plus 1. Otherwise, it returns the year
    of the input date.
    """
    if isinstance(date_, str):
        date_ = str_to_date(date_)
    if date_.month >= 7:
        return date_.year + 1
    else:
        return date_.year


@replace_newline
def date_to_str(date_):
    return date_.strftime("%d/%m/%Y")


def locate(location, data):
    """
    If the location is a list, get the first item in the list from the data,
    then call the function again with the remaining items in the list.
    This recursively searches the data stucture for the given key.
    """
    if isinstance(location, str):
        location = location.split(".")

    if isinstance(location, list):
        result = data.get(location[0], "Value not present in source data")
        location.pop(0)
        if location != [] and isinstance(result, str) == False:
            result = locate(location, result)
            return result
        else:
            return result


def check_address_list(address1, address_list, threshold):
    matched = []
    for address in address_list:
        match = address_match(address1, address, threshold=threshold)
        if match:
            matched.append(address)
    return len(matched), matched


def constricting_address_match(primary_address, addresses, threshold=80, step=0.1):
    """
    Matches primary address to addresses by progressively tightening the threshold
    values. Until there is either 1 match or none.

    Args:
        primary_address::str
            The primary address to be matched
        addresses::list
            list of addresses to be evaluated
        threshold::int default=80
            Starting threshold
        step::float default=0.1
            Increment the threshold by this amount
    Returns:
        bool
            Was a single match found?
        list
            All remaining matches
    """

    while True:
        len_match, addresses = check_address_list(primary_address, addresses, threshold)
        if len_match == 1:
            return True, addresses
        elif len_match == 0 or threshold >= 100:
            return False, addresses
        threshold += step


@replace_newline
def is_credit_card_number(value):
    # Normalise the value
    try:
        cc_num = "".join(filter(str.isdigit, value))

        if len(cc_num) == 16 and cc_num.isdigit():
            digits = list(map(int, cc_num))
            doubled_digits = [
                2 * digit if index % 2 else digit
                for index, digit in enumerate(digits[::-1])
            ]
            summed_digits = sum(
                digit - 9 if digit > 9 else digit for digit in doubled_digits
            )

            if summed_digits % 10 == 0:
                return True
    except:
        pass
    finally:
        # Basic Check

        ## is Visa
        pattern = r"^4[0-9]"
        match = re.search(pattern, value)
        if match:
            return True

        ## is MasterCard
        pattern = r"^5[1-5][0-9]"
        match = re.search(pattern, value)
        if match:
            return True

        ## Is Discover
        if (
            value.startswith("6011")
            or value.startswith("644")
            or value.startswith("65")
        ):
            return True

        ## is Amex
        if value.startswith("34") or value.startswith("37"):
            return True

    return False

