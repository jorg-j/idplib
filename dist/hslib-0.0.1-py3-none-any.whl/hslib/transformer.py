import functools

from fuzzywuzzy import fuzz


def replace_newline(func):
    def wrapper(*args, **kwargs):
        # first convert any None type args or kwargs to empty strings
        args = ["" if isinstance(arg, type(None)) else arg for arg in args]
        kwargs = {
            key: "" if isinstance(value, type(None)) else value
            for key, value in kwargs.items()
        }

        args = [arg.replace("\n", " ") if isinstance(arg, str) else arg for arg in args]
        kwargs = {
            key: value.replace("\n", " ") if isinstance(value, str) else value
            for key, value in kwargs.items()
        }
        return func(*args, **kwargs)

    return wrapper


def company_name_abbreviation(name):
    """
    Takes a company name as input and returns its abbreviation based on a predefined list
    of comparisons.

    :param name: A string representing the name of a company. The function aims to abbreviate the name
    of the company based on a set of predefined comparisons
    :return: a string that is the abbreviation of the given company name. If the given name matches any
    of the pre-defined company names or their variations, the function replaces it with the primary name
    and returns the abbreviation of the primary name. If the given name does not match any of the
    pre-defined company names, the function returns the original name.
    """
    name = name.replace("-", " ").replace("  ", " ")
    name = name.strip()

    comparisons_arr = [
        ["corporation", "corp"],
        ["commonwealth bank of australia", "commonwealth bank", "commbank", "cba"],
        ["national australia bank", "nab"],
        ["australia and new zealand banking group", "anz"],
        ["westpac banking corporation", "westpac", "wbc"],
        ["bendigo and adelaide bank limited", "bendigo bank", "adelaide bank"],
        ["bank of melbourne", "bom"],
        ["bank of queensland", "boq"],
        ["bank of sa", "bank of south australia", "bsa"],
        ["bank west", "bankwest"],
        ["citibank", "citi australia", "citi"],
        ["hongkong and shanghai banking corporation", "hsbc"],
        ["imbbank", "imb"],
        ["liberty financial", "liberty bank"],
        [
            "st. george banking group",
            "st.george banking group",
            "st. george bank limited",
            "st. george",
            "st george",
            "stgeorge",
        ],
        ["suncorp group limited", "suncorp"],
        ["australian associated motor insurers limited", "aami"],
        ["the rock financial group", "the rock"],
        ["australian mutual provident society", "amp"],
        ["macquarie group limited", "macquarie bank"],
    ]
    for comparisions in comparisons_arr:
        primary = comparisions[0].lower()
        for comparison in comparisions:
            if comparison.lower() in name.lower():
                name = name.lower().replace(comparison.lower(), primary)
                return name
    return name


@functools.lru_cache(maxsize=50)
def company_name_normalise(name):
    """
    Normalises a company name by removing brackets, banned words, and end notes.

    :param name: The name of a company that needs to be normalised
    :return: The function `company_name_normalise` returns a normalized version of the input `name`
    string, with certain characters and words removed or replaced according to the rules defined in the
    function. The returned value is a string.
    """
    """ """

    def remove_brackets(word):
        """
        Removes the brackets and their contents from a given word.

        :param word: The input string that may contain brackets that need to be removed
        :return: The function `remove_brackets` returns a string with the brackets and the content inside
        them removed.
        """
        l_bracket = word.find("(")
        r_bracket = word.find(")")
        first_part = word[:l_bracket]
        last_part = word[r_bracket + 1 :]
        removed_bracketed = first_part + last_part
        return removed_bracketed

    def banned_words_removal(word):
        """
        Removes a list of banned words from a given word.

        :param word: The input string that needs to be checked for banned words and have them removed
        :return: The function `banned_words_removal` returns a string with all the banned words removed.
        """
        banned_words = [
            "pty",
            "ltd",
            "p/l",
            "-",
            ".",
            ",",
            '"',
            "'",
            "@",
        ]
        for banned_word in banned_words:
            word = word.replace(banned_word, "")
        return word

    def remove_end_notes(word):
        """
        Removes specific words from the end of a given string.

        :param word: A string that may contain one of the end notes to be removed from the end of the string
        :return: the modified input string `word` with any of the specified `end_notes` removed from the end
        of the string.
        """
        # To be removed from END of string only
        end_notes = [
            "group",
            "trust",
            "limited",
            " inc",
        ]

        end_notes = sorted(end_notes, key=len, reverse=True)
        for end_note in end_notes:
            value = lower_name.rfind(end_note)
            if value != -1:
                sublength = len(word) - len(end_note)
                if sublength == value:
                    word = word[:sublength]
                    word.rstrip()
        return word

    lower_name = name.lower()
    if "(" in lower_name or ")" in lower_name:
        lower_name = remove_brackets(lower_name)

    policy_name = company_name_abbreviation(lower_name)
    lower_name = lower_name.strip()  # Remove White Space Noise
    lower_name = banned_words_removal(policy_name)
    lower_name = lower_name.strip()  # Remove White Space Noise
    lower_name = remove_end_notes(lower_name)
    lower_name = lower_name.strip()  # Remove White Space Noise

    return lower_name


@functools.lru_cache(maxsize=50)
@replace_newline
def company_name_compare(name1, name2, threshold=88):
    """
    Compares two company names after normalising them and returns True if their token sort
    ratio is above a given threshold.

    :param name1: The first company name to compare
    :param name2: The second company name to be compared
    :param threshold: The threshold is a value between 0 and 100 that determines the minimum similarity
    score required for the function to return True. If the similarity score between the two company
    names is below the threshold, the function will return False. The default threshold is set to 88,
    defaults to 88 (optional)
    :return: a boolean value (True or False) based on whether the token sort ratio between the two
    company names (after normalization) is greater than the threshold value.
    """
    name1 = company_name_normalise(name1)
    name2 = company_name_normalise(name2)
    value = fuzz.token_sort_ratio(name1, name2)
    return True if value > threshold else False


@replace_newline
def company_name_match_position(name1, document_data, lookup_field):
    """
    Compares a given company name with the values in a document using a
    lookup field and returns the result, position, and extracted value.

    :param name1: The name of the company that we are trying to match with the document data
    :param document_data: This is a dictionary containing data extracted from a document. It may contain
    multiple fields, each with multiple values
    :param lookup_field: The lookup_field parameter is a string that represents the prefix of the key
    used to store the data in the document_data dictionary. It is used to extract the relevant data from
    the dictionary for comparison with the name1 parameter. The function uses this parameter to loop
    through all possible keys in the dictionary to find
    :return: a tuple containing three values:
    1. A boolean value indicating whether there is a match between the given company name and the
    extracted value from the document data.
    2. An integer value indicating the position of the extracted value in the document data.
    3. A string value containing the extracted value from the document data.
    """
    position = 0
    # Loop through all possible names to check for a match

    while True:
        extracted_value = document_data.get(f"{lookup_field}_{str(position)}", {}).get(
            "transcription_normalised", ""
        )
        result = company_name_compare(name1, extracted_value)
        if result:
            break
        elif extracted_value == "":
            position -= 1
            extracted_value = document_data.get(
                f"{lookup_field}_{str(position)}", {}
            ).get("transcription_normalised", "")
            break
        else:
            position += 1

    if position < 0:
        position = 0  # set to zero in case of empty extracted_value string scenario
    return result, position, extracted_value


@functools.lru_cache(maxsize=500)
@replace_newline
def name_normalise(name):
    """
    Normalises a given name by removing any salutations or honorifics present at the start
    of the string.

    :param name: The input name that needs to be normalised by removing any salutations or honorifics
    present at the beginning of the name and returning the normalized name
    :return: a normalized version of the input name with any salutations or honorifics removed.
    """
    salutations = [
        "admiral ",
        "air comm ",
        "ambassador ",
        "baron ",
        "baroness ",
        "brig ",
        "brig gen ",
        "brigadier ",
        "brother ",
        "canon ",
        "capt ",
        "chief ",
        "cllr ",
        "col ",
        "commander ",
        "consul general ",
        "consul ",
        "count ",
        "countess ",
        "countess of ",
        "cpl ",
        "dame ",
        "deputy ",
        "drs ",
        "duchess ",
        "duke ",
        "earl ",
        "father ",
        "general ",
        "hma ",
        "her grace ",
        "his excellency ",
        "ing ",
        "judge ",
        "justice ",
        "lady ",
        "lic ",
        "llc ",
        "lord ",
        "lt ",
        "lt col ",
        "lt cpl ",
        "madam ",
        "madame ",
        "master ",
        "major general ",
        "major ",
        "marchioness ",
        "marquis ",
        "minister ",
        "mme ",
        "prince ",
        "princess ",
        "professor ",
        "prof dame ",
        "prof dr ",
        "prof ",
        "pvt ",
        "rabbi ",
        "rear admiral ",
        "rev ",
        "rev canon ",
        "rev dr ",
        "senator ",
        "sgt ",
        "sheriff ",
        "sir ",
        "sister ",
        "sqr. leader ",
        "the earl of ",
        "the hon dr ",
        "the hon lady ",
        "the hon lord ",
        "the hon mrs ",
        "the hon sir ",
        "the hon ",
        "the honourable ",
        "the rt hon dr ",
        "the rt hon lord ",
        "the rt hon sir ",
        "the rt hon visc ",
        "the rt hon ",
        "viscount ",
        "mr ",
        "mrs ",
        "miss ",
        "ms ",
        "mx ",
        "dr ",
    ]

    # Sort the salutations by length and backwards
    # This prevents a partial match from removing key match data from the name.
    sorted_salutations = sorted(salutations, key=len, reverse=True)
    lower_name = name.lower()
    lower_name = lower_name.replace(".", "").replace(",", " ").replace("'", "")
    # Remove honorifics, only if they are present at the start of string
    for honorific in sorted_salutations:
        location = lower_name.find(honorific)
        if location == 0:
            lower_name = lower_name.replace(honorific, "")
    honorific_removed = lower_name.replace(honorific, "")

    # Rejoin the name
    normalised_name = honorific_removed.replace("-", "").strip()

    return normalised_name


def name_middle_fallback(name1, name2, threshold=98):
    """
    Compares the similarity of the first and last names of two given names and returns True
    if the similarity score is above a given threshold.

    :param name1: The first name to compare, as a string
    :param name2: The second name to compare with name1
    :param threshold: The threshold is a numeric value that determines the minimum similarity score
    required for the function to return True. If the similarity score between the first and last names
    of the two input names is greater than the threshold, the function returns True, indicating that the
    names are similar enough. Otherwise, it returns False, defaults to 98 (optional)
    :return: a boolean value (True or False) based on whether the fuzzy string matching score between
    the first and last names of two input names is greater than a given threshold value.
    """
    name1_arr = name1.split(" ")
    name2_arr = name2.split(" ")
    first_last1 = f"{name1_arr[0]} {name1_arr[-1]}"
    first_last2 = f"{name2_arr[0]} {name2_arr[-1]}"
    value = fuzz.WRatio(first_last1, first_last2)
    return True if value > threshold else False


@functools.lru_cache(maxsize=128)
@replace_newline
def name_compare(name1, name2, threshold=88, token_ratio=89):
    """
    Compares two names and returns True if their similarity score is above a certain
    threshold, with a fallback option if the score is below the threshold.

    :param name1: The first name to compare
    :param name2: The variable "name2" is a string representing the second name to be compared
    :param threshold: The minimum score required for a match to be considered valid. If the score is
    below this threshold, the function will try to use a different matching method or return False,
    defaults to 88 (optional)
    :param token_ratio: The token_ratio parameter is the minimum score required for the function to
    consider the two names as a match when the WRatio score is below the threshold value. It is used in
    conjunction with the token_sort_ratio function from the fuzzywuzzy library, which compares the
    sorted tokens of the two names, defaults to 89 (optional)
    :return: a boolean value (True or False) indicating whether the two input names are considered a
    match based on their similarity score compared to the given threshold and token ratio. If the
    similarity score is below the threshold, the function checks the token sort ratio and if it is above
    the token ratio, it returns True. Otherwise, it falls back to a middle name comparison and returns
    the result of that
    """
    name1 = name_normalise(name1)
    name2 = name_normalise(name2)
    value = fuzz.WRatio(name1, name2)
    if value < threshold:
        value = fuzz.token_sort_ratio(name1, name2)
        if value > token_ratio:
            return True
        else:
            return name_middle_fallback(name1, name2)
    return True


@replace_newline
def name_match_position(name1, document_data, lookup_field):
    """
    Compares a given name with the values in a document data dictionary and returns the
    position and extracted value of the matching name.

    :param name1: The name to be matched with the document data
    :param document_data: a dictionary containing data extracted from a document
    :param lookup_field: The field in the document data that is being searched for a match with the
    given name
    :return: a tuple containing three values:
    1. A boolean value indicating whether there is a match between the given name1 and the extracted
    value from the document data.
    2. An integer value indicating the position of the extracted value in the document data.
    3. A string value containing the extracted value from the document data.
    """
    position = 0
    # Loop through all possible names to check for a match

    while True:
        extracted_value = document_data.get(f"{lookup_field}_{str(position)}", {}).get(
            "transcription_normalised", ""
        )
        result = name_compare(name1, extracted_value)
        if result:
            break
        elif extracted_value == "":
            position -= 1
            extracted_value = document_data.get(
                f"{lookup_field}_{str(position)}", {}
            ).get("transcription_normalised", "")
            break
        else:
            position += 1
    return result, position, extracted_value


@replace_newline
def bsb_transform(bsb):
    """
    Removes spaces and dashes from a given string and returns the modified string along
    with a boolean indicating if the length of the modified string is greater than or equal to 6.

    :param bsb: The input parameter "bsb" is a string representing a Bank State Branch (BSB) number
    :return: a tuple containing two values: the modified BSB string with spaces and dashes removed, and
    a boolean value indicating whether the length of the modified BSB string is greater than or equal to
    6.
    """
    bsb = bsb.replace(" ", "").replace("-", "")
    return bsb, len(bsb) != 6


@replace_newline
def normalise_digits(value1):
    """
    Removes spaces and dashes from a given string.mypy
    """
    return value1.replace(" ", "").replace("-", "").replace(",", "").replace("$", "")


@replace_newline
def compare_base_digits(value1, value2):
    """
    Compares two values after normalizing their digits.

    :param value1: The first value to be compared, which is expected to be a string representing a
    number in some base
    :param value2: I'm sorry, but the parameter value2 is not defined in the given code snippet. It
    seems to be missing. Can you please provide more information or context?
    :return: The function `compare_base_digits` is returning a boolean value indicating whether the two
    input values have the same digits after being normalized.
    """
    value1 = normalise_digits(value1)
    value2 = normalise_digits(value2)
    return value1 == value2


@replace_newline
def bsb_compare(bsb1, bsb2):
    """
    Compares two BSB numbers by calling the `compare_base_digits` function.

    :param bsb1: The first BSB to compare
    :param bsb2: The second BSB to be compared with bsb1
    :return: The function `bsb_compare` is returning the result of calling the function
    `compare_base_digits` with the arguments `bsb1` and `bsb2`.
    """
    return compare_base_digits(bsb1, bsb2)


@replace_newline
def account_number_compare(account1, account2):
    """
    Compares two account numbers after removing spaces and dashes and returns True if they
    are the same or have the same last four digits.

    :param account1: The first account number to compare, as a string with possible spaces and dashes
    :param account2: The second account number to compare, as a string with possible spaces and dashes
    :return: a boolean value (True or False) depending on whether the two account numbers passed as
    arguments are considered a match or not.
    """
    account1 = account1.replace(" ", "").replace("-", "")
    account2 = account2.replace(" ", "").replace("-", "")

    if any(len(x) > 16 for x in [account1, account2]):
        return False

    if account1 == account2:
        return True

    # Check if last 4 digits match
    elif account1[-4:] == account2[-4:]:
        return True

    return False


@replace_newline
def closing_balance_transform(balance, min_payment=None):
    """
    Transforms a given balance string into a float value and adds a negative sign if
    necessary based on the minimum payment.

    :param balance: The current balance of an account, represented as a string with a currency symbol
    (e.g. "$") and possibly a credit or debit indicator (e.g. "CR" or "DR")
    :param min_payment: The minimum payment amount for a credit card balance. It is an optional
    parameter that can be passed to the function
    :return: a float value of the closing balance after transforming it by removing any non-numeric
    characters and converting it to a negative value if it is a debit balance. If a minimum payment is
    provided, it also converts the balance to a negative value if it is not already negative. Also returns
    whether the tranformation was successful.
    """
    try:
        balance = (
            str(balance)
            .replace("$", "")
            .replace("CR", "")
            .replace(" ", "")
            .replace(",", "")
        )
        if "DR" in str(balance):
            balance = balance.replace("DR", "")
            balance = f"-{balance}"

        if min_payment is not None and min_payment.lower() not in [
            "",
            "no transcription",
        ]:
            if "-" not in str(balance):
                balance = f"-{balance}"
        return float(balance), True
    except:
        return 0, False


@replace_newline
def interest_rate_str_float(rate):
    """
    Converts an interest rate string to a float and rounds it to two decimal places.

    :param rate: The input parameter "rate" is expected to be a string representing an interest rate,
    with or without a percentage sign (%). The function converts this string to a float and rounds it to
    two decimal places. If the input is not a valid string representation of a number, the function
    returns 0
    :return: either the converted and rounded interest rate as a float or 0 if there is an error during
    the conversion process.
    """
    if rate == "":
        return 0
    try:
        if rate is not None and rate.lower() not in ["", "no transcription"]:
            rate = rate.replace("%", "")
            rate = float(rate)
            rate = round(rate, 2)
        return rate
    except:
        return 0


@replace_newline
def normalise_digit(value):
    """
    Normalises a given value by removing any dollar signs or commas and rounding it to two
    decimal places.

    :param value: The input value that needs to be normalised. It could be a string or a number with a
    dollar sign ($) and/or commas (,) in it. The function removes these characters and returns the
    normalised value as a float with two decimal places. If the input value cannot be converted to a
    float 0 will be returned
    :return: a normalised version of the input value. The input value is first converted to a string and
    any "$" or "," characters are removed. Then, the string is converted to a float and rounded to two
    decimal places. If the input value cannot be converted to a float, the function returns 0.
    """
    value = str(value).replace("$", "").replace(",", "")
    try:
        return round(float(value), 2)
    except:
        return 0
