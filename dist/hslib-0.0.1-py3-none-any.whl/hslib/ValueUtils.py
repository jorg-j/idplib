import functools
import re
from decimal import Decimal, ROUND_HALF_UP

from fuzzywuzzy import fuzz


def replace_newline(func):
    def wrapper(*args, **kwargs):
        # first convert any None type args or kwargs to empty strings
        args = ["" if isinstance(arg, type(None)) else arg for arg in args]
        kwargs = {
            key: "" if isinstance(value, type(None)) else value
            for key, value in kwargs.items()
        }

        args = [arg.replace("\n", " ") if isinstance(arg, str) else arg for arg in args]
        kwargs = {
            key: value.replace("\n", " ") if isinstance(value, str) else value
            for key, value in kwargs.items()
        }
        return func(*args, **kwargs)

    return wrapper


class Normalise:
    @staticmethod
    def digit(value: str, pattern: str = r"[ -\$,]") -> str:
        """
        Removes spaces and dashes from a given string.
        """
        return re.sub(pattern, "", value)
    
    @staticmethod
    def safe_round(value: float, decimal_places:int=2)-> float:
        # Convert the float to a Decimal object
        decimal_value = Decimal(str(value))
        
        # Round the Decimal object to n decimal places using proper rounding
        rounded_decimal = decimal_value.quantize(Decimal('1e-{}'.format(decimal_places)), rounding=ROUND_HALF_UP)
        
        # Convert the rounded Decimal back to a float
        rounded_float = float(rounded_decimal)
        
        return rounded_float


class Compare:
    @staticmethod
    def digits(value1: str, value2: str) -> bool:
        """
        The function `digits` compares two string values after normalizing
        them as digits and returns a
        boolean indicating if they are equal.

        :param value1: The function normalizes the input strings using a method
        `Normalise.digit` and then compares the normalized values to check
        if they are equal
        :type value1: str
        :type value2: str
        :return: a boolean value indicating whether the normalised versions
        of the two input values are
        equal.
        """
        normalised1 = Normalise.digit(value=value1)
        normalised2 = Normalise.digit(value=value2)
        return normalised1 == normalised2

    @staticmethod
    @functools.lru_cache(maxsize=128)
    @replace_newline
    def string_with_percent(
        value1: str, value2: str, threshold: int = 88, token_ratio: int = 89):
        value = fuzz.WRatio(value1, value2)
        if value < threshold:
            value = fuzz.token_sort_ratio(value1, value2)
            if value > token_ratio:
                return True, value
            else:
                return False, value
        return True, value

    @staticmethod
    @functools.lru_cache(maxsize=128)
    @replace_newline
    def string(
        value1: str, value2: str, threshold: int = 88, token_ratio: int = 89
    ) -> bool:
        result, _ = Compare.string_with_percent(value1, value2, threshold, token_ratio)
        return result
