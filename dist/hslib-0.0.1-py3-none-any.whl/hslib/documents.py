import re
from collections import defaultdict
from random import randint
from dataclasses import dataclass, field
import hashlib

# def hash_dict(item):
#     if isinstance(item, dict):
#         return frozenset((key, hash_dict(value)) for key, value in item.items())
#     elif isinstance(item, list):
#         return tuple(hash_dict(element) for element in item)
#     else:
#         return item


def hash_dict(item):
    normalised = str(item).encode("utf-8")
    sha = hashlib.sha256()
    sha.update(normalised)
    value = sha.hexdigest()
    return value


def _locate(location, data):
    """
    If the location is a list, get the first item in the list from the data,
    then call the function again with the remaining items in the list.
    This recursively searches the data stucture for the given key.
    """
    if isinstance(location, str):
        location = location.split(".")

    if isinstance(location, list):
        result = data.get(location[0], "Value not present in source data")
        location.pop(0)
        if location != [] and isinstance(result, str) == False:
            result = _locate(location, result)
            return result
        else:
            return result


def single_document_munge(document):
    """
    The function takes a document and extracts relevant information from its fields, returning a
    dictionary of the extracted data.

    :param document: A dictionary containing information about a document, including its layout name,
    page count, and document fields. The document fields are a list of dictionaries containing
    information about each field in the document, including its name, transcription, normalized
    transcription, and occurrence index
    :return: The function `single_document_munge` returns a dictionary containing information about a
    document, including its layout name, page count, and information about each field in the document
    (such as its name, transcription, and occurrence index).
    """

    def doc_fetch(dictionary):
        name = dictionary.get("field_name", "")
        transcription_normalised = dictionary.get("transcription_normalized", "")
        transcription = dictionary.get("transcription", "")
        occurrence_index = dictionary.get("occurrence_index", "No_Occurence")
        return name, transcription_normalised, transcription, occurrence_index

    document_fields = document["document_fields"]
    document_data = {}

    document_data["layout_name"] = document.get("layout_name", "")
    document_data["page_count"] = len(document.get("pages", ""))
    for field in document_fields:
        name, transcription_normalised, transcription, occurrence_index = doc_fetch(
            field
        )
        key_name = f"{name}_{occurrence_index}"
        document_data[key_name] = dict(
            transcription=transcription,
            transcription_normalised=transcription_normalised,
        )

    return document_data


def document_munge(document):
    """
    The function "document_munge" takes a document as input and returns the output of the function
    "single_document_munge" applied to that document.

    :param document: The input document that needs to be processed or modified in some way
    :return: The function `document_munge` is returning the result of calling the function
    `single_document_munge` with the argument `document`.
    """
    return single_document_munge(document)



def full_page_rollup(data):
    """
    The function takes in data and returns a concatenated string of all text segments in the data.

    :param data: The input data for the function, which is expected to be a dictionary containing
    information about a webpage. The dictionary should have a key called 'segments', which is a list of
    dictionaries representing different segments of the webpage. Each segment dictionary should have a
    'type' key indicating the type of segment (e
    :return: The function `full_page_rollup` takes a dictionary `data` as input and returns a string
    `body`. The string `body` is created by concatenating the `text` values of all segments in `data`
    where the `type` is `'text'`.
    """
    segments = data["segments"]
    body = " ".join(
        segment["text"].replace("\n", " ")
        for segment in segments
        if segment["type"] == "text"
    )
    return body


def fetch_document(layout_name, customer_data, all_document_data):
    """
    Fetches documents which align to a specific layout name
    Document ID for the document must be allocated to the customer.meta list

    layout_name - the layout to look for
    customer_data - the customer data after mapping and after document assignment
    all_document_data - Hyperscience documents json

    Note: document assignment refers to the customer_data containing
    meta.document_ids
    eg
    meta.document_ids = [1, 2]

    """
    document_ids = _locate("meta.document_ids", customer_data)
    document_response = []
    for document in all_document_data:
        document_id = document.get("id", 0)
        layout_name_1 = document.get("layout_name", "")
        if document_id in document_ids and layout_name_1 == layout_name:
            document_response.append(document)
    return document_response


def extract_normalised(field_name, packet):
    """
    Takes the munged single document as packet and fetches the normalised
    value for the specific field_name
    """
    results = packet.get(field_name, {})
    return results.get("transcription_normalised", "")


def set_normalised(document_data, field_name, value):
    """ """
    result = document_data.get(field_name, {})
    result["transcription_normalised"] = value
    document_data[field_name] = result
    return document_data


def remove_doc_string(string):
    pattern = r"DOC-\d\d\d "
    result = re.sub(pattern, "", string)
    return result


class Document:
    def __init__(self, document_raw):
        """
        Takes document_name
        document_name: The document title ie "ATO_Statement_John_Smith.pdf"
        """
        self.document_name = document_raw.get(
            "layout_name", "Unable to Determine Layout"
        )
        self.summary_title = remove_doc_string(self.document_name)
        self.doc_age = ""
        self.doc_age_met = False
        self.red_flags = False
        self.red_flag_list = []
        self.validations = []
        self.doc_id = document_raw.get("id", 0)
        self.filename = document_raw.get("filename", "Filename not found")
        self.custom_filename = self.filename
        self.url = document_raw.get("url", "URL not Found")
        self.folder = document_raw.get("folder", "Folder not found")
        self.page_count = len(document_raw.get("pages", []))
        self.document_fields = document_munge(document_raw)
        self.meta = {}

        self.doc_pass = True
        self.doc_strength = 0
        self.link_hash = ""

        # appends to the summary notes (used in doc 12, 4, 3, 6)
        self._summary_notes = []

    def add_summary_note(self, note):
        self._summary_notes.append(note)

    def _process_summary_notes(self):
        if self._summary_notes:
            self.summary_notes = "\n".join(self._summary_notes)
        else:
            self.summary_notes = ""

    def update_summary_title(self, value):
        current_title = self.summary_title
        self.summary_title = f"{current_title} - {value}"

    def create_hash(self, payload):
        payload_hash = hash_dict(payload)
        self.link_hash = payload_hash

    def add_red_flag(self, flag):
        """
        This function adds a red flag to a list and sets a boolean variable to True.

        :param flag: The flag parameter is a variable that represents the red flag being added to a list of
        red flags
        """
        self.red_flag_list.append(flag)
        self.red_flags = True

    def add_validation(
        self, validation_id, title, extracted="", application="", result=""
    ):
        """
        The function adds a validation to a list of validations with specified parameters.

        :param validation_id: a unique identifier for the validation being added
        :param title: The title or name of the field being validated
        :param extracted: This parameter refers to the data that was extracted from a document or source. It
        could be a name, address, date, or any other relevant information that needs to be validated
        :param application: The source data or system from which the data was extracted for validation
        :param result: The "OBP Match / Verified to Policy" parameter is used to indicate whether the
        validation result matches the policy or not. It is a boolean value that can be set to either "True"
        or "False". If the validation result matches the policy, then it is considered to be a successful
        validation
        """
        payload = {}
        payload["validation_id"] = validation_id
        payload["Field"] = title
        payload["Doc Data Extracted"] = extracted
        payload["Application Source Data"] = application
        payload["OBP Match / Verified to Policy"] = result
        self.validations.append(payload)

    def add_val(self, validation):
        packed = validation.pack()

        r = packed["OBP Match / Verified to Policy"]
        if r:
            self.doc_strength += 1
        else:
            self.doc_pass = False

        self.validations.append(packed)

    def pack(self):
        self._process_summary_notes()
        return vars(self)


class Validation:
    """
    Validation class to help document details
    """

    def __init__(
        self,
        validation_id,
        label,
        is_ready=False,
        direct=False,
        result=False,
        outcome_message="Verified to Application",
        assessor_message="",
        broker_message="",
    ):
        self.validation_id = validation_id
        self.label = label
        self.is_ready = is_ready

        self.extracted_value = ""
        self.application_value = ""

        # Column E DocDetails

        # If result == True
        self.outcome_message = outcome_message
        # If result == False
        self.assessor_message = assessor_message
        # Column E DocDetails

        self.broker_message = broker_message

        self.cell_color = ""

        self.result = result
        self.hide_row = False

        # Flag to state if this validation is ready for message switch
        # remove after all changes are actioned
        self.is_ready = is_ready

        if direct:
            self.result = True
            self.outcome_message = "N/A"
            self.cell_color = "None"

    def _auto_col(self):
        if self.cell_color == "" and self.is_ready:
            if self.result:
                self.cell_color = "Green"
            else:
                self.cell_color = "Orange"

    def pack(self):
        self._auto_col()
        payload = vars(self)
        payload["Field"] = self.label
        payload["Doc Data Extracted"] = self.extracted_value
        payload["Application Source Data"] = self.application_value
        payload["OBP Match / Verified to Policy"] = self.result
        payload["DocDetailsMsg"] = (
            self.outcome_message if self.result == True else self.assessor_message
        )

        return payload


class TableToFields:
    """
    Takes the table from a HS document and pulls all fields into an array
    calling reconstruct_document and feeding in the original document data will
    put the table data in the document_fields as if they were originally extracted as fields.
    The purge argument will remove from document_fields any fields which could conflict with
    the table data
    """

    def __init__(self, tables):
        self.table_values = defaultdict(dict)
        self.reindexed = {}
        self.columns = []
        self.field_names = set()
        self.new_fields = []

        for table in tables:
            self.columns.extend(table["columns"])

        self._process_columns()
        self.reset_indexes()
        self._transform()

    def _process_columns(self):
        for column in self.columns:
            field_name = column["field_name"]
            self.field_names.add(field_name)
            cells = column["cells"]
            for cell in cells:
                self._process_cell(cell, field_name)

        self.field_names = list(self.field_names)

    def _get_index_value(self, row_number, page_number):
        index_position = f"{page_number}{row_number}"
        return self.table_values[index_position]

    def _process_cell(self, cell, field_name):
        row_number = cell["row_number"]
        page_number = cell["page_number"]
        transcription = cell["transcription"]
        transcription_normalised = cell["transcription_normalized"]
        index_value = self._get_index_value(row_number, page_number)
        index_value[field_name] = dict(
            transcription=transcription,
            transcription_normalized=transcription_normalised,
        )

    def reset_indexes(self):
        self.reindexed = {
            counter: v for counter, v in enumerate(self.table_values.values())
        }

    def _transform(self):
        self.new_fields = [
            {
                "field_name": field_name,
                "occurrence_index": occurrence,
                "transcription": transcriptions["transcription"],
                "transcription_normalized": transcriptions["transcription_normalized"],
            }
            for occurrence, values in self.reindexed.items()
            for field_name, transcriptions in values.items()
        ]

    def reconstruct_document(self, document_data, purge=False):
        document_fields = document_data["document_fields"]

        if purge:
            document_fields = [
                field
                for field in document_fields
                if field["field_name"] not in self.field_names
            ]

        document_fields.extend(self.new_fields)

        document_data["document_fields"] = document_fields
        return document_data
