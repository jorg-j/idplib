# IDP Python Utilities

The purpose of this library is to provide useful tools to support IDP based processes


## Install

```
pip install IDPlib
```

## Usage

Useage will be broken down into a few concepts. General and tool specific.

### General

ValueUtils 

```
from IDPlib import ValueUtils

# Normalisers

# Takes a digit as a string and returns a string 
# Removes spaces, hyphens, comma, dollar sign
# Or you can submit your own pattern to normalise, this allows you to handle for specific cases

result = ValueUtils.Normalise.digit('$5')
>>> '5'

result = ValueUtils.Normalise.digit('5%', pattern=r"[ -\$,%]")
>>> '5'

# Safely round numbers as python can incorrectly round floating point digits

result = ValueUtils.Normalise.safe_round(1.515)
>>> 1.52

result = ValueUtils.Normalise.safe_round(1.5155, decimal_places=3)
>>> 1.5

# Dates

# converti

```
